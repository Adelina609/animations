package ru.kpfu.itis.android.animationsapp.di.list.scope

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class ListScope
