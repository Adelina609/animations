package ru.kpfu.itis.android.animationsapp.ui.details

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.arellomobile.mvp.MvpAppCompatFragment
import com.arellomobile.mvp.presenter.InjectPresenter
import com.arellomobile.mvp.presenter.ProvidePresenter
import ru.kpfu.itis.android.animationsapp.App
import ru.kpfu.itis.android.animationsapp.R
import ru.kpfu.itis.android.animationsapp.di.list.component.DaggerListComponent
import ru.kpfu.itis.android.animationsapp.di.list.module.ListModule
import ru.kpfu.itis.android.animationsapp.di.list.module.PresenterModule
import ru.kpfu.itis.android.animationsapp.presenter.DetailsPresenter
import javax.inject.Inject

class DetailsFragment : MvpAppCompatFragment(), DetailsView {

    @Inject
    @InjectPresenter
    lateinit var detailsPresenter: DetailsPresenter

    @ProvidePresenter
    fun getPresenter(): DetailsPresenter = detailsPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        DaggerListComponent.builder()
            .appComponent(App.getAppComponents())
            .presenterModule(PresenterModule())
            .listModule(ListModule())
            .build()
            .inject(this)
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_details_main, container, false)
}
