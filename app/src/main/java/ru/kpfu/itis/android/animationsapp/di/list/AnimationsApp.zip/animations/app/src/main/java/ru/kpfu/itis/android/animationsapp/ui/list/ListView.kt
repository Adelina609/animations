package ru.kpfu.itis.android.animationsapp.ui.list

import com.arellomobile.mvp.MvpView
import ru.kpfu.itis.android.animationsapp.model.Item

interface ListView : MvpView {
    fun displayList(list: List<Item>)
    fun animateScroll()
}
