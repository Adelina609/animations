package ru.kpfu.itis.android.animationsapp.ui.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.list_item_main.view.*
import ru.kpfu.itis.android.animationsapp.R
import ru.kpfu.itis.android.animationsapp.model.Item

class Adapter(
    private val list: List<Item>,
    private val sourceLambda: (Item) -> Unit
) :
    ListAdapter<Item, Adapter.ItemHolder>(
        ItemDiffCallback()
    ) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_main, parent, false)
        return ItemHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {
        holder.bind(list[position], sourceLambda)
    }

    class ItemDiffCallback : DiffUtil.ItemCallback<Item>() {
        override fun areItemsTheSame(oldItem: Item, newItem: Item): Boolean =
            oldItem.title == newItem.title

        override fun areContentsTheSame(oldItem: Item, newItem: Item): Boolean = oldItem == newItem

    }

    class ItemHolder(override val containerView: View) : RecyclerView.ViewHolder(containerView),
        LayoutContainer {
        fun bind(item: Item, clickListener: (Item) -> Unit) {
            with(containerView) {
                containerView.tv_title_item.text = item.title
                containerView.iv_item.setImageResource(item.imageId)
                setOnClickListener { clickListener(item) }
            }
        }
    }
}
