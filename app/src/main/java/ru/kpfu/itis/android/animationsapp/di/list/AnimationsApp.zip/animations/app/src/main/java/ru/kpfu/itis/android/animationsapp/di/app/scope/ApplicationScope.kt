package ru.kpfu.itis.android.animationsapp.di.app.scope

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class ApplicationScope
