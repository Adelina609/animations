package ru.kpfu.itis.android.animationsapp.ui.details

import com.arellomobile.mvp.MvpView

interface DetailsView : MvpView {
}
