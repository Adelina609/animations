package ru.kpfu.itis.android.animationsapp.presenter

import android.transition.Fade
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentManager
import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import ru.kpfu.itis.android.animationsapp.R
import ru.kpfu.itis.android.animationsapp.model.Item
import ru.kpfu.itis.android.animationsapp.ui.details.DetailsFragment
import ru.kpfu.itis.android.animationsapp.ui.list.AnimatingTransition
import ru.kpfu.itis.android.animationsapp.ui.list.ListView
import ru.kpfu.itis.android.animationsapp.utils.ListCreator
import javax.inject.Inject

@InjectViewState
class ListPresenter(
    private val listCreator: ListCreator
) : MvpPresenter<ListView>() {

    fun getList() {
        viewState.displayList(listCreator.getCreatedList())
    }

    fun itemClick(item: Item, fragmentManager: FragmentManager?, imageView: ImageView, textView: TextView){
        val fragment = DetailsFragment()
        fragment.sharedElementEnterTransition = AnimatingTransition()
        fragment.enterTransition = Fade()
        fragment.exitTransition = Fade()
        fragment.returnTransition = AnimatingTransition()

        fragmentManager
            ?.beginTransaction()
            ?.addSharedElement(imageView,"iv_transition")
            ?.addSharedElement(textView,"tv_transition")
            ?.replace(R.id.container_main, fragment)
            ?.commit()
    }
}
