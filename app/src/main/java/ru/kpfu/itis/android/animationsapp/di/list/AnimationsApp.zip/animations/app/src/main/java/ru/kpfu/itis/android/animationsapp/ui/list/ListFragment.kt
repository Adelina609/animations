package ru.kpfu.itis.android.animationsapp.ui.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.arellomobile.mvp.MvpAppCompatFragment
import com.arellomobile.mvp.presenter.InjectPresenter
import com.arellomobile.mvp.presenter.ProvidePresenter
import kotlinx.android.synthetic.main.fragment_list_main.*
import kotlinx.android.synthetic.main.list_item_main.*
import ru.kpfu.itis.android.animationsapp.App
import ru.kpfu.itis.android.animationsapp.R
import ru.kpfu.itis.android.animationsapp.di.list.component.DaggerListComponent
import ru.kpfu.itis.android.animationsapp.di.list.module.ListModule
import ru.kpfu.itis.android.animationsapp.di.list.module.PresenterModule
import ru.kpfu.itis.android.animationsapp.model.Item
import ru.kpfu.itis.android.animationsapp.presenter.ListPresenter
import javax.inject.Inject

class ListFragment : MvpAppCompatFragment(), ListView {

    @Inject
    @InjectPresenter
    lateinit var listPresenter: ListPresenter

    @ProvidePresenter
    fun getPresenter(): ListPresenter = listPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        DaggerListComponent.builder()
            .appComponent(App.getAppComponents())
            .presenterModule(PresenterModule())
            .listModule(ListModule())
            .build()
            .inject(this)
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_list_main, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initAdapter()
        listPresenter.getList()
    }

    private fun initAdapter() {
        if (rv_main.adapter == null) {
            rv_main.layoutManager = LinearLayoutManager(context)
            rv_main.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    if (dy < 0) {
                        val fadeIn: Animation =
                            AnimationUtils.loadAnimation(context, R.anim.fade_out)
                        tv_title_list
                            .animate().setDuration(500).alpha(0f).withEndAction { tv_title_list.isVisible = false }
                    }
                    if (dy > 0) {
                        tv_title_list.animate().setDuration(500).alpha(1f).withStartAction { tv_title_list.isVisible = true }
//                            .startAnimation(fadeIn)
//
//
//                    }
//                    if (dy > 0) {
//                        val fadeIn: Animation =
//                            AnimationUtils.loadAnimation(context, R.anim.fade_out)
//                        tv_title_list.startAnimation(fadeIn)
                    }
                }
            })
        }
    }

    override fun displayList(list: List<Item>) {
        if (rv_main.adapter == null) {
            rv_main.adapter = Adapter(list) {
                listPresenter.itemClick(
                    it, activity?.supportFragmentManager,
                    iv_item, tv_title_item
                )
            }
        }
        (rv_main.adapter as Adapter).submitList(list)
    }

    override fun animateScroll() {
    }
}
