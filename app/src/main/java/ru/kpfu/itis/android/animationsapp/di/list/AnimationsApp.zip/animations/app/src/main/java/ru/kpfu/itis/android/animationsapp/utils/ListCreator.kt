package ru.kpfu.itis.android.animationsapp.utils

import ru.kpfu.itis.android.animationsapp.R
import ru.kpfu.itis.android.animationsapp.model.Item

class ListCreator {

    fun getCreatedList(): List<Item> {
        val item = Item("Title", R.drawable.ic_launcher_background)
        return listOf<Item>(item, item, item, item, item, item)
    }
}
