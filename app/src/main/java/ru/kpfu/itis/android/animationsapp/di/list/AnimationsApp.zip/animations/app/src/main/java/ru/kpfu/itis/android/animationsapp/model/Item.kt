package ru.kpfu.itis.android.animationsapp.model

data class Item(
    val title: String,
    val imageId: Int
)
