package ru.kpfu.itis.android.animationsapp.presenter

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import ru.kpfu.itis.android.animationsapp.ui.details.DetailsView

@InjectViewState
class DetailsPresenter : MvpPresenter<DetailsView>(){

}
